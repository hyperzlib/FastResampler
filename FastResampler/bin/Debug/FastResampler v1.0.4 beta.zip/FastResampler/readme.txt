Before use, please copy wavtool.exe and resampler.exe into the "engines" folder (or edit FastResampler.exe and fill in the address of wavtool and resampler).
Then, change the voice setting and change the wavtool and resampler to FastResampler.exe .
Now, you can enjoy the fast of FastResampler.